from django.db import models
from django.db.models.fields import IntegerField, TextField
from django.db.models.fields.files import ImageField

class pakage(models.Model):
    pname = TextField()
    desc = TextField()
    amount = IntegerField()

class destination(models.Model):
    name = TextField()
    desc = TextField()
    image = ImageField()