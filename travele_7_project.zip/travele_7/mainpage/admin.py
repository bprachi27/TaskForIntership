from mainpage.models import destination, pakage
from django.contrib import admin

# Register your models here.
admin.site.register(pakage)
admin.site.register(destination)